﻿Free FatCow-Farm Fresh Icons
http://www.fatcow.com/free-icons

FatCow Farm-Fresh final release (3926 icons, 5 parts):
- fatcow-hosting-icons-3.9.2.zip default (10.9 Mb)
- fatcow-hosting-icons-3.9.2-color.zip (11.1 Mb)
- fatcow-hosting-icons-3.9.2-grey.zip (6.9 Mb)
- fatcow-hosting-icons-3.9.2-ico.zip (8.9 Mb)
- fatcow-hosting-icons-3.9.2-all.zip (30.7 Mb)
- fatcow-hosting-icons-3.9.2-ai-src.zip (2.82 !Gb)

These icons are licensed under a Creative Commons Attribution 3.0 License.
http://creativecommons.org/licenses/by/3.0/us/ if you do not know how to link
back to FatCow's website, you can ask https://plus.google.com/+MarcisGasuns
Biggest icon set drawn by a single designer (in pixel smooth style) worldwide.

We are unavailable for custom icon design work. The project is
closed (April 2014) and we do not plan to draw more metaphors.
http://twitter.com/FatCow
http://plus.google.com/+FatCow
http://www.facebook.com/FatCow

---------------------------------------------------------------------------------

© Copyright 2009-2014 FatCow Web Hosting. All rights reserved.
http://www.fatcow.com

All other trademarks and copyrights
are property of their respective owners.

---------------------------------------------------------------------------------
